/**
 * 
 */
package com.service.bean;

/**
 * @author User
 *
 */
public class UserBean {
	
	private int id;
	private String name;
	private int createdAt;
	private String imageUrl;

/**
 * @return the id
 */
public int getId() {
	return id;
}

/**
 * @param id the id to set
 */
public void setId(int id) {
	this.id = id;
}

/**
 * @return the name
 */
public String getName() {
	return name;
}

/**
 * @param name the name to set
 */
public void setName(String name) {
	this.name = name;
}

/**
 * @return the createdAt
 */
public int getCreatedAt() {
	return createdAt;
}

/**
 * @param createdAt the createdAt to set
 */
public void setCreatedAt(int createdAt) {
	this.createdAt = createdAt;
}

/**
 * @return the imageUrl
 */
public String getImageUrl() {
	return imageUrl;
}

/**
 * @param imageUrl the imageUrl to set
 */
public void setImageUrl(String imageUrl) {
	this.imageUrl = imageUrl;
}







	
}
