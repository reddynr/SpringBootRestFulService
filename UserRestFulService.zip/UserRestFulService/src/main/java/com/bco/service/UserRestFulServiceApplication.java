package com.bco.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class UserRestFulServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserRestFulServiceApplication.class, args);
	}
}
