/**
 * 
 */
package com.bco.service;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.service.bean.UserBean;

/**
 * @author User
 *
 */
@Controller
public class UserController {
	
	public static UserBean userBean;
	/**
	 * 
	 */
	public UserController() {
		// TODO Auto-generated constructor stub
	}
	 @GetMapping("/userBean/user")
    @ResponseBody
    public UserBean getUsers( UserBean userBean) {
    	userBean.setId(1);
		userBean.setCreatedAt(1234567);
    	userBean.setName("Name 12");
    	userBean.setImageUrl("https://unsplash.it/500?image=12");
     	return userBean;

    }
 


}
